    DisableWrite ${WINEPREFIX}/drive_c/users/${USER}/Temp
    CallProcess "$@"
