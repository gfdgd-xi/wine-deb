CallProcess "$@"
sleep 2
/opt/apps/com.163.dashi.mailmaster.spark/files/disable_mailmaster_shadows
